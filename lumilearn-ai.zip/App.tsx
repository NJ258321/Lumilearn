
import React, { useState } from 'react';
import Layout from './components/Layout';
import BottomNav from './components/BottomNav';
import Dashboard from './pages/Dashboard';
import Courses from './pages/Courses';
import Agent from './pages/Agent';
import Drill from './pages/Drill';
import TimeMachine from './pages/TimeMachine';
import Recorder from './pages/Recorder';
import CourseDetailReview from './pages/CourseDetailReview';
import { AppView } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.DASHBOARD);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [currentCourseId, setCurrentCourseId] = useState<string | null>(null);

  const navigate = (view: AppView, data?: any) => {
    setCurrentView(view);
    if (data) setCurrentCourseId(data);
  };

  const renderView = () => {
    switch (currentView) {
      case AppView.DASHBOARD:
        return <Dashboard onNavigate={navigate} />;
      case AppView.COURSES:
        return <Courses onNavigate={navigate} />;
      case AppView.COURSE_DETAIL_REVIEW:
        return <CourseDetailReview onNavigate={navigate} />;
      case AppView.COURSE_DETAIL_STUDY:
        // Reuse Courses for now or separate logic
        return <Courses onNavigate={navigate} />;
      case AppView.AGENT:
        return <Agent />;
      case AppView.DRILL:
        return <Drill onNavigate={navigate} />;
      case AppView.TIME_MACHINE:
        return <TimeMachine onBack={() => navigate(AppView.DASHBOARD)} />;
      case AppView.RECORDER:
        return <Recorder onBack={() => navigate(AppView.DASHBOARD)} />;
      default:
        return <Dashboard onNavigate={navigate} />;
    }
  };

  const showNav = [
    AppView.DASHBOARD, 
    AppView.COURSES, 
    AppView.AGENT, 
    AppView.DRILL,
    // AppView.COURSE_DETAIL_REVIEW, // Hide BottomNav in Immersive Detail
    AppView.COURSE_DETAIL_STUDY
  ].includes(currentView);

  return (
    <Layout>
      {renderView()}
      {showNav && <BottomNav currentView={currentView} onNavigate={navigate} />}
    </Layout>
  );
};

export default App;
