import React, { useState, useRef, useMemo, useEffect } from 'react';
import { ArrowLeft, Play, ChevronRight, Folder, Flame } from 'lucide-react';
import { AppView } from '../types';

interface CourseDetailReviewProps {
  onNavigate: (view: AppView) => void;
}

// --- 1. MOCK DATA ---
const PHOTOGRAMMETRY_DATA = {
  id: "course-001",
  title: "摄影测量学",
  structure: [
    {
      id: "cat-1",
      title: "绪论",
      children: [
        { id: "ch-1", title: "第一章：绪论", leaves: [
          { id: "l-1-1", name: "摄影测量定义", status: "mastered" },
          { id: "l-1-2", name: "发展历程", status: "mastered" }
        ]}
      ]
    },
    {
      id: "cat-2",
      title: "解析摄影测量",
      children: [
        { id: "ch-2", title: "第二章：单幅影像解析基础", leaves: [
          { id: "l-2-1", name: "中心投影构像", status: "mastered" },
          { id: "l-2-2", name: "常用坐标系", status: "reviewing" },
          { id: "l-2-3", name: "共线条件方程", status: "weak" }, 
          { id: "l-2-4", name: "空间后方交会", status: "reviewing" }
        ]},
        { id: "ch-3", title: "第三章：双像立体测图", leaves: [
          { id: "l-3-1", name: "立体视觉原理", status: "mastered" },
          { id: "l-3-2", name: "核线相关", status: "weak" }
        ]},
        { id: "ch-4", title: "第四章：解析空中三角测量", leaves: [
          { id: "l-4-1", name: "解析空中三角测量相关知识", status: "mastered" },
          { id: "l-4-2", name: "光束法空中三角测量", status: "reviewing" },
          { id: "l-4-3", name: "解析空中三角测量最新发展", status: "weak" }
        ]}
      ]
    },
    {
      id: "cat-3",
      title: "数字摄影测量",
      children: [
        { id: "ch-5", title: "第五章：数字影像与特征提取", leaves: [
          { id: "l-5-1", name: "数字影像采样", status: "mastered" },
          { id: "l-5-2", name: "影像重采样理论", status: "reviewing" },
          { id: "l-5-3", name: "特征提取算法", status: "weak" },
          { id: "l-5-4", name: "植面与横线以及核线的重采样", status: "mastered" }
        ]},
        { id: "ch-6", title: "第六章：影像匹配基础理论与算法", leaves: [
            { id: "l-6-1", name: "影像相关原理", status: "mastered" },
            { id: "l-6-2", name: "影像相关的谱分析", status: "reviewing" },
            { id: "l-6-3", name: "数字影像匹配基本算法", status: "weak" },
            { id: "l-6-4", name: "基于物方的影像匹配(VLL法)", status: "mastered" },
            { id: "l-6-5", name: "影像匹配精度", status: "reviewing" },
            { id: "l-6-6", name: "最小二乘影像匹配", status: "weak" },
            { id: "l-6-7", name: "特征匹配", status: "mastered" }
        ]},
        { id: "ch-7", title: "第七章：数字地面模型的建立与应用", leaves: [
          { id: "l-7-1", name: "数字地面模型", status: "mastered" },
          { id: "l-7-2", name: "数字高程模型的内插方法", status: "reviewing" },
          { id: "l-7-3", name: "DEM的精度及存贮管理", status: "weak" },
          { id: "l-7-4", name: "三角网数字地面模型(TIN)", status: "mastered" },
          { id: "l-7-5", name: "数字地面模型的应用", status: "reviewing" }
        ]},
        { id: "ch-8", title: "第八章：数字微分纠正", leaves: [
          { id: "l-8-1", name: "数字微分纠正的概念", status: "mastered" },
          { id: "l-8-2", name: "框幅式中心投影影像的数字微分纠正", status: "reviewing" },
          { id: "l-8-3", name: "线性阵列扫描影像的数字纠正", status: "weak" },
          { id: "l-8-4", name: "正射影像的质量控制", status: "mastered" }
        ]}
      ]
    }
  ]
};

// --- 2. LAYOUT TYPES ---
interface GraphNode {
    id: string;
    type: 'root' | 'cat' | 'ch' | 'leaf';
    x: number;
    y: number;
    data: any;
    width: number;
    height: number;
}
interface GraphLink {
    source: GraphNode;
    target: GraphNode;
    color: string;
}

// Config constants - Dynamic based on mode
const CONFIG_MACRO = {
    ROOT_X: 50,
    LEVEL_GAP: 160, // Tighter
    NODE_H: 60,
    CH_GAP: 80,     // Fixed gap between chapters
    FONT_SCALE: 1.2
};

const CONFIG_MICRO = {
    ROOT_X: 50,
    LEVEL_GAP: 280, // Wider for leaves
    LEAF_H: 60,
    FONT_SCALE: 1.0
};

const SEMANTIC_THRESHOLD = 0.85; // Scale below this triggers Micro (Detail) mode

const CourseDetailReview: React.FC<CourseDetailReviewProps> = ({ onNavigate }) => {
  // Canvas State
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1.0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const lastPos = useRef({ x: 0, y: 0 });

  // Sheet State
  const SHEET_MAX_HEIGHT = 450; // Approximated max height content
  const SHEET_MIN_HEIGHT = 120; // Handle + Title
  const [sheetHeight, setSheetHeight] = useState(SHEET_MIN_HEIGHT + 140); // Initial partially open
  const [isDraggingSheet, setIsDraggingSheet] = useState(false);
  const sheetStartY = useRef(0);
  const sheetStartHeight = useRef(0);

  // Derived Mode
  const isMicroMode = transform.scale < SEMANTIC_THRESHOLD;

  // --- LAYOUT ENGINE (Memoized) ---
  const { nodes, links } = useMemo(() => {
    const nodes: GraphNode[] = [];
    const links: GraphLink[] = [];
    
    let currentY = 0;

    // --- MODE A: MACRO (Compact, No Leaves) ---
    if (!isMicroMode) {
        const rootNode: GraphNode = {
            id: 'root', type: 'root', x: CONFIG_MACRO.ROOT_X, y: 0, width: 180, height: 50, data: { title: PHOTOGRAMMETRY_DATA.title }
        };

        const catNodes: GraphNode[] = [];

        PHOTOGRAMMETRY_DATA.structure.forEach((cat, catIdx) => {
            const catNode: GraphNode = {
                id: cat.id, type: 'cat', x: CONFIG_MACRO.ROOT_X + CONFIG_MACRO.LEVEL_GAP, y: 0, width: 150, height: 80, data: cat
            };
            
            const chNodes: GraphNode[] = [];
            cat.children.forEach((ch) => {
                const chNode: GraphNode = {
                    id: ch.id, type: 'ch', x: CONFIG_MACRO.ROOT_X + CONFIG_MACRO.LEVEL_GAP * 2.2, y: currentY, width: 220, height: 50, data: ch
                };
                nodes.push(chNode);
                chNodes.push(chNode);
                currentY += CONFIG_MACRO.CH_GAP;
            });

            // Position Cat
            if (chNodes.length > 0) {
                catNode.y = (chNodes[0].y + chNodes[chNodes.length - 1].y) / 2;
            } else {
                catNode.y = currentY; 
                currentY += CONFIG_MACRO.CH_GAP;
            }
            nodes.push(catNode);
            catNodes.push(catNode);

            // Links Cat->Ch
            const catColor = catIdx === 0 ? '#60A5FA' : (catIdx === 1 ? '#3B82F6' : '#8B5CF6');
            chNodes.forEach(ch => links.push({ source: catNode, target: ch, color: catColor }));
            
            currentY += 40; // Gap between Cats
        });

        // Position Root
        if (catNodes.length > 0) rootNode.y = (catNodes[0].y + catNodes[catNodes.length - 1].y) / 2;
        nodes.push(rootNode);
        catNodes.forEach(cat => links.push({ source: rootNode, target: cat, color: '#94A3B8' }));

    } 
    // --- MODE B: MICRO (Detailed, With Leaves) ---
    else {
        const rootNode: GraphNode = {
            id: 'root', type: 'root', x: CONFIG_MICRO.ROOT_X, y: 0, width: 180, height: 50, data: { title: PHOTOGRAMMETRY_DATA.title }
        };

        const catNodes: GraphNode[] = [];

        PHOTOGRAMMETRY_DATA.structure.forEach((cat, catIdx) => {
            const catNode: GraphNode = {
                id: cat.id, type: 'cat', x: CONFIG_MICRO.ROOT_X + CONFIG_MICRO.LEVEL_GAP, y: 0, width: 160, height: 100, data: cat
            };
            
            const chNodes: GraphNode[] = [];
            
            cat.children.forEach((ch) => {
                const chNode: GraphNode = {
                    id: ch.id, type: 'ch', x: CONFIG_MICRO.ROOT_X + CONFIG_MICRO.LEVEL_GAP * 2, y: 0, width: 240, height: 0, data: ch
                };

                const leafNodes: GraphNode[] = [];
                ch.leaves.forEach((leaf) => {
                    const leafNode: GraphNode = {
                        id: leaf.id, type: 'leaf', x: CONFIG_MICRO.ROOT_X + CONFIG_MICRO.LEVEL_GAP * 3.2, y: currentY, width: 260, height: 44, data: leaf
                    };
                    nodes.push(leafNode);
                    leafNodes.push(leafNode);
                    currentY += CONFIG_MICRO.LEAF_H;
                });

                if (leafNodes.length > 0) {
                    chNode.y = (leafNodes[0].y + leafNodes[leafNodes.length - 1].y) / 2;
                } else {
                    chNode.y = currentY;
                    currentY += CONFIG_MICRO.LEAF_H;
                }
                nodes.push(chNode);
                chNodes.push(chNode);

                // Links Ch->Leaf
                leafNodes.forEach(leaf => links.push({ source: chNode, target: leaf, color: '#CBD5E1' }));
                currentY += 20; // Gap between Chapters
            });

            if (chNodes.length > 0) catNode.y = (chNodes[0].y + chNodes[chNodes.length - 1].y) / 2;
            nodes.push(catNode);
            catNodes.push(catNode);

            // Links Cat->Ch
            const catColor = catIdx === 0 ? '#60A5FA' : (catIdx === 1 ? '#3B82F6' : '#8B5CF6');
            chNodes.forEach(ch => links.push({ source: catNode, target: ch, color: catColor }));
            currentY += 40; 
        });

        if (catNodes.length > 0) rootNode.y = (catNodes[0].y + catNodes[catNodes.length - 1].y) / 2;
        nodes.push(rootNode);
        catNodes.forEach(cat => links.push({ source: rootNode, target: cat, color: '#94A3B8' }));
    }

    return { nodes, links };
  }, [isMicroMode]);

  // Initial Centering
  useEffect(() => {
     if (containerRef.current) {
         const root = nodes.find(n => n.type === 'root');
         if (root) {
            setTransform({ x: 50, y: -root.y + 300, scale: 1.0 }); // Start at Macro 1.0
         }
     }
  }, []);

  // --- INTERACTION: Canvas ---
  const handlePointerDown = (e: React.PointerEvent) => {
    containerRef.current?.setPointerCapture(e.pointerId);
    setIsDragging(true);
    lastPos.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - lastPos.current.x;
    const dy = e.clientY - lastPos.current.y;
    setTransform(prev => ({ ...prev, x: prev.x + dx, y: prev.y + dy }));
    lastPos.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    containerRef.current?.releasePointerCapture(e.pointerId);
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        const zoomSensitivity = 0.001;
        const newScale = Math.min(Math.max(0.3, transform.scale - e.deltaY * zoomSensitivity), 2.0);
        setTransform(prev => ({ ...prev, scale: newScale }));
    } else {
        setTransform(prev => ({ ...prev, y: prev.y - e.deltaY }));
    }
  };

  // --- INTERACTION: Sheet Drag ---
  const handleSheetDragStart = (e: React.PointerEvent) => {
    e.stopPropagation();
    setIsDraggingSheet(true);
    sheetStartY.current = e.clientY;
    sheetStartHeight.current = sheetHeight;
    (e.currentTarget as Element).setPointerCapture(e.pointerId);
  };

  const handleSheetDragMove = (e: React.PointerEvent) => {
    if (!isDraggingSheet) return;
    e.stopPropagation();
    const deltaY = sheetStartY.current - e.clientY; // Drag UP increases height
    let newHeight = sheetStartHeight.current + deltaY;
    
    // Constraints with elasticity
    if (newHeight > SHEET_MAX_HEIGHT + 20) newHeight = SHEET_MAX_HEIGHT + (newHeight - SHEET_MAX_HEIGHT) * 0.2;
    if (newHeight < SHEET_MIN_HEIGHT - 20) newHeight = SHEET_MIN_HEIGHT - (SHEET_MIN_HEIGHT - newHeight) * 0.2;
    
    setSheetHeight(newHeight);
  };

  const handleSheetDragEnd = (e: React.PointerEvent) => {
    if (!isDraggingSheet) return;
    setIsDraggingSheet(false);
    (e.currentTarget as Element).releasePointerCapture(e.pointerId);

    // Snap Physics
    if (sheetHeight > (SHEET_MAX_HEIGHT + SHEET_MIN_HEIGHT) / 2) {
        setSheetHeight(SHEET_MAX_HEIGHT);
    } else {
        setSheetHeight(SHEET_MIN_HEIGHT);
    }
  };

  const getSigmoidPath = (source: GraphNode, target: GraphNode) => {
    const isCh = source.type === 'ch';
    // Adjust visual connection points based on node visual width
    const srcWidth = !isMicroMode && isCh ? 220 : (source.type === 'root' ? 180 : (source.type === 'cat' ? 150 : 240));
    
    const x1 = source.x + srcWidth; 
    const y1 = source.y;
    const x2 = target.x - (target.type === 'ch' ? 20 : 0);
    const y2 = target.y;

    const cx1 = x1 + (x2 - x1) * 0.5;
    const cx2 = x2 - (x2 - x1) * 0.5;
    return `M ${x1} ${y1} C ${cx1} ${y1}, ${cx2} ${y2}, ${x2} ${y2}`;
  };

  return (
    <div className="h-screen w-full bg-[#F8FAFC] overflow-hidden relative font-sans text-slate-800 flex flex-col">
        
        {/* =======================
            LAYER 1: COMPACT HEADER (Row Layout)
            ======================= */}
        <div className="flex-none pt-12 pb-2 px-6 bg-gradient-to-b from-white/95 via-white/80 to-transparent z-30 pointer-events-none">
             <div className="pointer-events-auto flex items-center w-full">
                <button 
                    onClick={() => onNavigate(AppView.COURSES)}
                    className="w-9 h-9 rounded-full bg-white/60 backdrop-blur-md border border-slate-200 shadow-sm flex items-center justify-center mr-3 active:scale-95 transition-transform"
                >
                    <ArrowLeft size={18} className="text-slate-600" />
                </button>
                <div className="flex-1 min-w-0">
                    <div className="flex items-baseline space-x-2">
                        <h1 className="text-xl font-black text-slate-800 tracking-tight truncate">摄影测量学</h1>
                        <span className="text-[10px] font-bold bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded whitespace-nowrap">专业核心</span>
                    </div>
                </div>
             </div>
        </div>

        {/* =======================
            LAYER 0: DYNAMIC CANVAS (Physical resizing)
            ======================= */}
        <div 
            ref={containerRef}
            className="absolute inset-0 z-0 cursor-grab active:cursor-grabbing touch-none w-full"
            style={{ 
                bottom: sheetHeight, // Link bottom edge to sheet height
                transition: isDraggingSheet ? 'none' : 'bottom 0.5s cubic-bezier(0.32, 0.72, 0, 1)'
            }}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onWheel={handleWheel}
        >
            {/* Dot Pattern */}
            <div className="absolute -inset-[4000px] opacity-60 pointer-events-none"
                 style={{
                     backgroundImage: 'radial-gradient(#CBD5E1 1.5px, transparent 1.5px)',
                     backgroundSize: '24px 24px'
                 }}
            ></div>

            <div 
                className="w-full h-full origin-center will-change-transform transition-transform duration-300"
                style={{ transform: `translate(${transform.x}px, ${transform.y}px) scale(${transform.scale})` }}
            >
                 <svg className="absolute top-[-5000px] left-[-5000px] w-[10000px] h-[10000px] overflow-visible pointer-events-none">
                    <g transform={`translate(5000, 5000)`}>
                    {links.map((link, i) => (
                        <path 
                            key={i}
                            d={getSigmoidPath(link.source, link.target)}
                            fill="none"
                            stroke={link.color}
                            strokeWidth={link.target.type === 'leaf' ? 1.5 : 2}
                            strokeOpacity={0.5}
                        />
                    ))}
                    </g>
                </svg>

                <div className="absolute top-0 left-0">
                {nodes.map(node => {
                    const isReviewing = node.data.status === 'reviewing';
                    
                    if (node.type === 'root') {
                        return (
                            <div key={node.id} 
                                 className="absolute flex items-center justify-center bg-slate-800 text-white rounded-full shadow-xl border-4 border-slate-100"
                                 style={{ left: node.x, top: node.y, width: node.width, height: node.height, transform: 'translate(0, -50%)' }}
                            >
                                <span className="font-bold text-lg">{node.data.title}</span>
                            </div>
                        );
                    }
                    if (node.type === 'cat') {
                        return (
                            <div key={node.id} 
                                 className="absolute flex items-center justify-center bg-blue-50 text-blue-700 border-2 border-blue-200 rounded-2xl shadow-sm px-4 text-center transition-all duration-300"
                                 style={{ left: node.x, top: node.y, width: node.width, height: node.height, transform: 'translate(0, -50%)' }}
                            >
                                <span className="font-bold leading-tight" style={{ fontSize: isMicroMode ? '14px' : '16px' }}>{node.data.title}</span>
                            </div>
                        );
                    }
                    if (node.type === 'ch') {
                        return (
                            <div key={node.id} 
                                 className={`absolute flex items-center bg-white border rounded-xl shadow-sm px-4 border-l-4 transition-all duration-300 ${!isMicroMode ? 'border-slate-200 border-l-blue-400 hover:shadow-md' : 'border-slate-100 border-l-slate-300'}`}
                                 style={{ left: node.x, top: node.y, width: node.width, height: !isMicroMode ? 50 : 60, transform: 'translate(0, -50%)' }}
                            >
                                <span className={`font-bold text-slate-700 ${!isMicroMode ? 'text-base' : 'text-sm'}`}>{node.data.title}</span>
                                {/* In Macro mode, show a small badge if needed */}
                                {!isMicroMode && (
                                    <div className="ml-auto bg-slate-100 text-slate-500 text-[10px] px-2 py-0.5 rounded-full">
                                        {node.data.leaves.length} 考点
                                    </div>
                                )}
                            </div>
                        );
                    }
                    if (node.type === 'leaf' && isMicroMode) {
                        return (
                            <div 
                                key={node.id}
                                onClick={() => onNavigate(AppView.TIME_MACHINE)}
                                className={`absolute flex items-center justify-between bg-white border rounded-full shadow-sm px-4 hover:scale-105 active:scale-95 transition-all cursor-pointer group ${isReviewing ? 'border-blue-200 ring-2 ring-blue-50' : 'border-slate-100'}`}
                                style={{ left: node.x, top: node.y, width: node.width, height: node.height, transform: 'translate(0, -50%)' }}
                            >
                                <span className={`text-xs ${node.data.status === 'weak' ? 'font-extrabold text-slate-800' : 'font-medium text-slate-600'}`}>{node.data.name}</span>
                                <div className="relative flex items-center justify-center w-3 h-3">
                                    {isReviewing && <span className="absolute w-full h-full rounded-full bg-red-400 opacity-30 animate-ping"></span>}
                                    <span className={`relative w-2 h-2 rounded-full ${isReviewing ? 'bg-red-500' : (node.data.status === 'mastered' ? 'bg-emerald-400' : 'bg-yellow-400')}`}></span>
                                </div>
                            </div>
                        );
                    }
                    return null;
                })}
                </div>
            </div>
            
            {/* Zoom Indicator Hint */}
            <div className={`absolute bottom-6 left-1/2 transform -translate-x-1/2 bg-black/70 text-white px-3 py-1 rounded-full text-xs transition-opacity duration-300 pointer-events-none ${isMicroMode ? 'opacity-0' : 'opacity-100'}`}>
                 双指捏合查看知识点 (Zoom Out)
            </div>
        </div>

        {/* =======================
            LAYER 2: DRAGGABLE BOTTOM SHEET
            ======================= */}
        <div 
            className="absolute bottom-0 left-0 right-0 z-40 bg-white rounded-t-[24px] shadow-[0_-10px_40px_-10px_rgba(0,0,0,0.1)] overflow-hidden flex flex-col"
            style={{ 
                height: sheetHeight,
                transition: isDraggingSheet ? 'none' : 'height 0.5s cubic-bezier(0.32, 0.72, 0, 1)'
            }}
        >
            {/* DRAG HANDLE */}
            <div 
                className="w-full pt-3 pb-2 cursor-grab active:cursor-grabbing flex-none bg-white z-10"
                onPointerDown={handleSheetDragStart}
                onPointerMove={handleSheetDragMove}
                onPointerUp={handleSheetDragEnd}
            >
                <div className="w-10 h-1.5 bg-slate-200 rounded-full mx-auto mb-3 mt-1"></div>
                <div className="px-6 flex items-center text-slate-800 pointer-events-none">
                    <Flame size={16} className="text-orange-500 mr-2" fill="#F97316" />
                    <h3 className="text-sm font-bold">今日待办 (2)</h3>
                </div>
            </div>
            
            {/* CONTENT AREA */}
            <div className="flex-1 overflow-y-auto mt-2 pb-6">
                {/* Section 1: Today's Tasks */}
                <div className="mb-6">
                    <div className="flex space-x-3 overflow-x-auto px-6 scrollbar-hide">
                        {/* Task Card 1 */}
                        <div className="flex-shrink-0 w-[240px] bg-white border border-slate-100 rounded-2xl p-4 shadow-sm relative overflow-hidden group active:scale-95 transition-transform" onClick={() => onNavigate(AppView.TIME_MACHINE)}>
                            <div className="absolute top-0 left-0 w-1 h-full bg-orange-400"></div>
                            <div className="flex justify-between items-start mb-2">
                                <span className="text-[10px] font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded">重点突破</span>
                                <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-blue-50 transition-colors">
                                    <Play size={14} className="text-slate-400 group-hover:text-blue-600 ml-0.5" fill="currentColor" />
                                </div>
                            </div>
                            <h4 className="font-bold text-slate-800 text-sm">共线条件方程推导</h4>
                            <p className="text-[10px] text-slate-400 mt-1">预计耗时 15min</p>
                        </div>

                        {/* Task Card 2 */}
                        <div className="flex-shrink-0 w-[240px] bg-white border border-slate-100 rounded-2xl p-4 shadow-sm relative overflow-hidden active:scale-95 transition-transform">
                            <div className="absolute top-0 left-0 w-1 h-full bg-purple-400"></div>
                            <div className="flex justify-between items-start mb-2">
                                <span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded">章节测验</span>
                                <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center">
                                    <ChevronRight size={16} className="text-slate-400" />
                                </div>
                            </div>
                            <h4 className="font-bold text-slate-800 text-sm">坐标系转换计算题</h4>
                            <p className="text-[10px] text-slate-400 mt-1">共 5 道选择题</p>
                        </div>
                    </div>
                </div>

                {/* Section 2: Resources Button */}
                <div className="px-6">
                    <button className="w-full bg-slate-50 border border-slate-100 rounded-xl p-4 flex items-center justify-between active:scale-[0.98] transition-transform">
                        <div className="flex items-center">
                            <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center mr-3">
                                <Folder size={20} fill="currentColor" fillOpacity={0.2} />
                            </div>
                            <div className="text-left">
                                <div className="text-sm font-bold text-slate-800">全部文档资料</div>
                                <div className="text-[10px] text-slate-400">12 个录音 · 5 份 PPT · 32 页笔记</div>
                            </div>
                        </div>
                        <ChevronRight size={18} className="text-slate-300" />
                    </button>
                </div>
            </div>
        </div>

    </div>
  );
};

export default CourseDetailReview;